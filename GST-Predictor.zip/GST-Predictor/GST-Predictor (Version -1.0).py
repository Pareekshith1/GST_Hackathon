""" The Testing Model """
""" GST-Predictor (Version -1.0) """
""" This code uses the Weight from either of the two testing models (Exhaustive_Grid_Search_model or 
Randomized_Search_Model)"""
""" The output AUC-ROC graph, Precision-Recall curve, and Feature Importance plot are visualized """

import pandas as pd
from catboost import CatBoostClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             confusion_matrix, roc_curve, auc, log_loss, balanced_accuracy_score, precision_recall_curve)
import plotly.graph_objects as go

# Load the dataset for deployment
new_data = pd.read_csv("C:\\Users\\DELL\\Desktop\\GST HACKATHON\\Datasets\\Test_20\\Test_20\\X_Test_Data_Input.csv")
new_target = pd.read_csv("C:\\Users\\DELL\\Desktop\\GST HACKATHON\\Datasets\\Test_20\\Test_20\\Y_Test_Data_Target.csv")

# Merge the features and target datasets on the common 'ID' column
merged_new_data = pd.merge(new_data, new_target, on='ID')

# Separate the features (X) and target variable (y) for the new dataset
X_new = merged_new_data.drop(["ID", "target"], axis=1)
y_new = merged_new_data['target']

# Load the best model saved during training
best_model = CatBoostClassifier()
best_model.load_model("./CatBoost_Randomized_Seed44_Split2_LR10_Depth6_Iter1500.cbm")

# Use the best model to make predictions on the new dataset
y_pred_new = best_model.predict(X_new)
y_prob_new = best_model.predict_proba(X_new)[:, 1]  # Probabilities for the positive class

# Evaluate the performance of the model on the new dataset
accuracy = accuracy_score(y_new, y_pred_new)
precision = precision_score(y_new, y_pred_new)
recall = recall_score(y_new, y_pred_new)
f1 = f1_score(y_new, y_pred_new)
logloss = log_loss(y_new, y_prob_new)
balanced_acc = balanced_accuracy_score(y_new, y_pred_new)
conf_matrix = confusion_matrix(y_new, y_pred_new)
fpr, tpr, _ = roc_curve(y_new, y_prob_new)
roc_auc = auc(fpr, tpr)

# Print the evaluation metrics
print(f"Deployment Model Performance:")
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1 Score: {f1:.4f}")
print(f"Log Loss: {logloss:.4f}")
print(f"Balanced Accuracy: {balanced_acc:.4f}")
print(f"Confusion Matrix:\n{conf_matrix}")
print(f"AUC-ROC: {roc_auc:.4f}")

# ROC Curve Visualization
fig = go.Figure()
fig.add_trace(go.Scatter(x=fpr, y=tpr, mode='lines', name='ROC Curve'))
fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode='lines', name='Random', line=dict(dash='dash')))
fig.update_layout(title=f'ROC Curve (AUC = {roc_auc:.4f})', xaxis_title='False Positive Rate', yaxis_title='True Positive Rate')
fig.show()

# Precision-Recall Curve Visualization
precision, recall, _ = precision_recall_curve(y_new, y_prob_new)
fig = go.Figure()
fig.add_trace(go.Scatter(x=recall, y=precision, mode='lines', name='Precision-Recall Curve'))
fig.update_layout(title='Precision-Recall Curve', xaxis_title='Recall', yaxis_title='Precision')
fig.show()

# Feature Importance Visualization
# Retrieve feature importances
feature_importances = best_model.get_feature_importance()
features = X_new.columns

# Create a DataFrame for easier plotting
importance_df = pd.DataFrame({
    'Feature': features,
    'Importance': feature_importances
}).sort_values(by='Importance', ascending=False)

# Plot Feature Importances
fig = go.Figure()
fig.add_trace(go.Bar(x=importance_df['Feature'], y=importance_df['Importance'], name='Feature Importances'))
fig.update_layout(title='Feature Importances', xaxis_title='Feature', yaxis_title='Importance')
fig.show()

# Save the predictions to a CSV file (Optional)
"""
new_data['Predicted_Target'] = y_pred_new
new_data.to_csv("./Predicted_Results.csv", index=False)
print("Predictions saved to Predicted_Results.csv")
"""
