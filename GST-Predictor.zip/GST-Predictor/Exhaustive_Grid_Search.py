""" Exhaustive Grid Search Model """
""" Iterating through every possible combination of parameters to find the best one which suits the dataset """
""" This processing model is made to adjust itself according to the given dataset to bring the best outcome """

# Importing the necessary packages
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# Loading the training and testing dataset from the system
df_train = pd.read_csv("C:\\Users\\DELL\\Desktop\\GST HACKATHON\\Datasets\\Train_60\\Train_60\\X_Train_Data_Input.csv")
df_test = pd.read_csv("C:\\Users\\DELL\\Desktop\\GST HACKATHON\\Datasets\\Train_60\\Train_60\\Y_Train_Data_Target.csv")

# Merging the dataset together
merged_df = pd.merge(df_train, df_test, on='ID')

# Assigning the values to the variables
X = merged_df.drop(["ID", "target"], axis=1)
y = merged_df['target']

# Setting up the Seed, Test_split, Learning_rate, Depth, Iteration
Seed = [42, 44, 88, 2020, 1000]
Split_ratio = [0.1, 0.2, 0.3, 0.4, 0.5]
Learning_rates = [0.01, 0.05, 0.1]
Depth = [4, 6, 8]
Iteration = [500, 1000, 1500]

# Adding the result array variable
result = []

# Variables to keep track of the best model
best_f1_score = -1
best_model = None
best_params = {}

# Starting to loop over each of the self-updating values
# Iterating through each and every combination to get the best possible parameters
for seed in Seed:
    for split_ratio in Split_ratio:
        for lr in Learning_rates:
            for depth in Depth:
                for iteration in Iteration:
                    # Printing the currently used parameters
                    print(f"Testing with the following parameters: Seed={seed}, Split_ratio={split_ratio}, "
                          f"Learning_rate={lr}, Depth={depth}, Iteration={iteration}")

                    # Splitting of the data
                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=split_ratio, random_state=seed)

                    # Calling the CatBoostClassify Algorithm
                    model = CatBoostClassifier(iterations=iteration, learning_rate=lr, depth=depth, verbose=False)

                    # Fitting the model with the dataset
                    model.fit(X_train, y_train, eval_set=(X_test, y_test), early_stopping_rounds=50)

                    # Make predictions
                    y_pred = model.predict(X_test)

                    # Evaluate the model
                    accuracy = accuracy_score(y_test, y_pred)
                    precision = precision_score(y_test, y_pred)
                    recall = recall_score(y_test, y_pred)
                    f1 = f1_score(y_test, y_pred)

                    # Print the results
                    print(
                        f"Results -> Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1 Score: {f1:.4f}")

                    # Save the results
                    result.append({
                        "Seed": seed,
                        "Split Ratio": split_ratio,
                        "Learning Rate": lr,
                        "Depth": depth,
                        "Iterations": iteration,
                        "Accuracy": accuracy,
                        "Precision": precision,
                        "Recall": recall,
                        "F1 Score": f1
                    })

                    # Check if this is the best model so far
                    if f1 > best_f1_score:
                        best_f1_score = f1
                        best_model = model
                        best_params = {
                            "Seed": seed,
                            "Split Ratio": split_ratio,
                            "Learning Rate": lr,
                            "Depth": depth,
                            "Iterations": iteration
                        }

# Find the best configuration based on F1 Score
print(f"Best Configuration: Seed: {best_params['Seed']}, Split Ratio: {best_params['Split Ratio']}, "
      f"Learning Rate: {best_params['Learning Rate']}, Depth: {best_params['Depth']}, "
      f"Iterations: {best_params['Iterations']}")
print(f"With F1 Score: {best_f1_score:.4f}")

# Save the best model
if best_model:
    best_model_filename = (
        f"CatBoost_Seed{best_params['Seed']}_Split{int(best_params['Split Ratio'] * 10)}_LR{int(best_params['Learning Rate'] * 100)}_"
        f"Depth{best_params['Depth']}_Iter{best_params['Iterations']}.cbm")
    best_model.save_model(best_model_filename)
    print(f"Best model saved as {best_model_filename}")
