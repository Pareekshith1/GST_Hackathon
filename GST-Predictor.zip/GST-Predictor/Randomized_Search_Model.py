""" Randomized Search Model """
""" This script performs a randomized search to find the best hyperparameters for the CatBoostClassifier. """
""" The model is evaluated based on the F1 score, and the best model configuration is saved. """

# Importing the necessary packages
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import numpy as np

# Loading the training and target datasets
df_train = pd.read_csv("C:\\Users\\DELL\\Desktop\\GST HACKATHON\\Datasets\\Train_60\\Train_60\\X_Train_Data_Input.csv")
df_test = pd.read_csv("C:\\Users\\DELL\\Desktop\\GST HACKATHON\\Datasets\\Train_60\\Train_60\\Y_Train_Data_Target.csv")

# Merging datasets on 'ID'
merged_df = pd.merge(df_train, df_test, on='ID')

# Separating features and target variable
X = merged_df.drop(["ID", "target"], axis=1)
y = merged_df['target']

# Defining parameter distributions for Randomized Search
param_dist = {
    'iterations': [500, 1000, 1500],          # Number of boosting iterations
    'learning_rate': [0.01, 0.05, 0.1],       # Learning rate for gradient descent
    'depth': [4, 6, 8],                       # Depth of trees
    'random_state': [42, 44, 88, 2020, 1000], # Random seed for reproducibility
    'test_size': [0.1, 0.2, 0.3, 0.4, 0.5]   # Proportion of data to be used for testing
}

# Variables to track the best model
best_f1_score = -1
best_model = None
best_params = {}

# Performing Randomized Search
for _ in range(10):  # Number of iterations for randomized search
    # Randomly sample parameters
    random_params = {key: np.random.choice(value) for key, value in param_dist.items()}

    seed = random_params.pop('random_state')
    split_ratio = random_params.pop('test_size')

    # Splitting the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=split_ratio, random_state=seed)

    # Initialize the CatBoost model with sampled parameters
    model = CatBoostClassifier(iterations=random_params['iterations'],
                               learning_rate=random_params['learning_rate'],
                               depth=random_params['depth'],
                               verbose=False)

    # Fit the model on the training data
    model.fit(X_train, y_train, eval_set=(X_test, y_test), early_stopping_rounds=50)

    # Predict on the test data
    y_pred = model.predict(X_test)

    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    # Print the results for the current parameter set
    print(f"Testing with parameters: Seed={seed}, Split_ratio={split_ratio}, "
          f"Learning_rate={random_params['learning_rate']}, Depth={random_params['depth']}, "
          f"Iterations={random_params['iterations']}")
    print(f"Results -> Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1 Score: {f1:.4f}")

    # Update the best model if the current F1 score is higher
    if f1 > best_f1_score:
        best_f1_score = f1
        best_model = model
        best_params = {
            "Seed": seed,
            "Split Ratio": split_ratio,
            "Learning Rate": random_params['learning_rate'],
            "Depth": random_params['depth'],
            "Iterations": random_params['iterations']
        }

# Print the best configuration based on F1 Score
print(f"Best Configuration: Seed: {best_params['Seed']}, Split Ratio: {best_params['Split Ratio']}, "
      f"Learning Rate: {best_params['Learning Rate']}, Depth: {best_params['Depth']}, "
      f"Iterations: {best_params['Iterations']}")
print(f"With F1 Score: {best_f1_score:.4f}")

# Save the best model
if best_model:
    best_model_filename = (f"CatBoost_Randomized_Seed{best_params['Seed']}_Split{int(best_params['Split Ratio']*10)}_LR{int(best_params['Learning Rate']*100)}_"
                          f"Depth{best_params['Depth']}_Iter{best_params['Iterations']}.cbm")
    best_model.save_model(best_model_filename)
    print(f"Best model saved as {best_model_filename}")
